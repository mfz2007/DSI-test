package com.dsi.real;
import android.app.Activity;import android.os.Bundle;import android.webkit.*;import android.graphics.Color;import java.io.*;import java.nio.charset.StandardCharsets;
public final class MainActivity extends Activity{
 WebView w;
 @Override public void onCreate(Bundle b){super.onCreate(b);w=new WebView(this);w.setBackgroundColor(Color.BLACK);WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setUseWideViewPort(true);s.setLoadWithOverviewMode(false);s.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/155.0.0.0 Safari/537.36");w.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String url){try{InputStream in=getAssets().open("skin.js");byte[] x=new byte[in.available()];in.read(x);in.close();v.evaluateJavascript(new String(x,StandardCharsets.UTF_8),null);}catch(Exception ignored){}}});w.loadUrl("https://chatgpt.com/");setContentView(w);}
 @Override protected void onDestroy(){if(w!=null)w.destroy();super.onDestroy();}
}
