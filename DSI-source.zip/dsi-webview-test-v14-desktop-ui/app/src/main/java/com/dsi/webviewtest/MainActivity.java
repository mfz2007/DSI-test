package com.dsi.webviewtest;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

import android.net.Uri;

/**
 * CSS/DOM desktop layout around the real ChatGPT WebView.
 *
 * The shell lives inside the webpage so the visual layout stays close to a
 * desktop ChatGPT/Codex page. Android only supplies the WebView and the
 * standard file chooser callback; it never reads credentials or cookies.
 */
public final class MainActivity extends Activity {
    private static final String START_URL = "https://chatgpt.com/";
    private static final int BACKGROUND = Color.BLACK;
    private static final int GOLD = Color.rgb(218, 170, 72);
    private static final int FILE_CHOOSER_REQUEST = 7014;

    private static final String DESKTOP_USER_AGENT =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36";

    /**
     * Create the Codex-like rail, top bar and compact composer in the real
     * ChatGPT DOM. The original input and upload controls remain in the DOM.
     */
    private static final String DESKTOP_SCRIPT = """
            (function () {
              var SHELL_ID = 'dsi-css-shell-v14';
              var STYLE_ID = 'dsi-css-style-v14';

              function box(el) {
                return el ? el.getBoundingClientRect() :
                    {x: 0, y: 0, width: 0, height: 0};
              }
              function visible(el) {
                var r = box(el);
                return r.width > 0 && r.height > 0;
              }
              function inShell(el) {
                return !!(el && el.closest && el.closest('#' + SHELL_ID));
              }
              function mark(el, name) {
                if (el && !inShell(el)) el.setAttribute(name, '1');
              }
              function pageText(el) {
                return ((el.innerText || '') + ' ' +
                        (el.getAttribute('aria-label') || '') + ' ' +
                        (el.getAttribute('title') || '')).trim();
              }
              function pageButtons() {
                return Array.from(document.querySelectorAll(
                    'button,a,[role="button"],label')).filter(function (el) {
                  return !inShell(el) && visible(el);
                });
              }
              function clickPage(re) {
                var item = pageButtons().find(function (el) {
                  return re.test(pageText(el));
                });
                if (item) {
                  item.click();
                  return true;
                }
                return false;
              }
              function findPageInput() {
                return Array.from(document.querySelectorAll('input[type="file"]'))
                  .find(function (el) { return !inShell(el); }) || null;
              }
              function openUpload(mime) {
                var input = findPageInput();
                if (input) {
                  var old = input.getAttribute('accept');
                  input.setAttribute('accept', mime);
                  try { input.click(); } catch (e) {}
                  setTimeout(function () {
                    if (old === null) input.removeAttribute('accept');
                    else input.setAttribute('accept', old);
                  }, 1200);
                  return;
                }
                var attachRe = /add photos|photos and files|attach|upload|上传|照片|图片|文件/i;
                if (clickPage(attachRe)) {
                  setTimeout(function () { clickPage(attachRe); }, 180);
                }
              }
              function sendText(value) {
                var target = document.querySelector(
                    '#prompt-textarea,textarea,[contenteditable="true"]');
                if (!target) return;
                target.focus();
                if (target.tagName === 'TEXTAREA') {
                  var setter = Object.getOwnPropertyDescriptor(
                      HTMLTextAreaElement.prototype, 'value');
                  if (setter && setter.set) setter.set.call(target, value);
                  else target.value = value;
                } else {
                  target.textContent = value;
                }
                target.dispatchEvent(new InputEvent('input', {
                  bubbles: true,
                  inputType: 'insertText',
                  data: value
                }));
                setTimeout(function () {
                  clickPage(/send|发送|submit/i);
                }, 120);
              }

              function markPageChrome() {
                Array.from(document.querySelectorAll(
                    'aside,nav,[data-testid*="sidebar"]')).forEach(function (el) {
                  if (inShell(el)) return;
                  var r = box(el);
                  if (r.width > 0 && r.width < innerWidth * .48) {
                    mark(el, 'data-dsi-original-sidebar');
                  }
                });

                Array.from(document.querySelectorAll('header')).forEach(function (el) {
                  if (inShell(el)) return;
                  var r = box(el);
                  if (r.y < 140 && r.width > innerWidth * .45 && r.height < 180) {
                    mark(el, 'data-dsi-original-header');
                  }
                });

                var input = document.querySelector(
                    '#prompt-textarea,textarea,[contenteditable="true"]');
                if (input && !inShell(input)) {
                  var form = input.closest('form');
                  if (form) {
                    mark(form, 'data-dsi-original-composer');
                  } else {
                    var parent = input.parentElement;
                    for (var i = 0; i < 7 && parent; i++, parent = parent.parentElement) {
                      if (!inShell(parent) && box(parent).width > innerWidth * .35) {
                        mark(parent, 'data-dsi-original-composer');
                        break;
                      }
                    }
                  }
                }

                Array.from(document.querySelectorAll('div,p,footer')).forEach(function (el) {
                  if (inShell(el)) return;
                  var t = (el.innerText || '').trim();
                  if (t.indexOf('ChatGPT 是 AI') >= 0 && t.length < 320) {
                    mark(el, 'data-dsi-disclaimer');
                  }
                });
              }

              function installStyle() {
                var style = document.getElementById(STYLE_ID);
                if (!style) {
                  style = document.createElement('style');
                  style.id = STYLE_ID;
                  (document.head || document.documentElement).appendChild(style);
                }
                style.textContent = `
                  :root {
                    --dsi-rail: 218px;
                    --dsi-rail-collapsed: 62px;
                    --dsi-top: 58px;
                    --dsi-composer-space: 104px;
                    --dsi-bg: #000000;
                    --dsi-panel: #202020;
                    --dsi-panel-2: #171717;
                    --dsi-border: #333333;
                    --dsi-text: #f3f3f3;
                    --dsi-muted: #a0a0a0;
                    --dsi-gold: #d9aa48;
                  }
                  html, body {
                    width: 100% !important;
                    height: 100% !important;
                    min-height: 100% !important;
                    margin: 0 !important;
                    background: var(--dsi-bg) !important;
                    color: var(--dsi-text) !important;
                  }
                  body {
                    overflow: hidden !important;
                    padding-left: var(--dsi-rail) !important;
                    padding-top: var(--dsi-top) !important;
                    padding-bottom: var(--dsi-composer-space) !important;
                    box-sizing: border-box !important;
                  }
                  [data-testid="desktop-app-shell"],
                  #web-mobile-root,
                  main, [role="main"] {
                    width: 100% !important;
                    max-width: none !important;
                    min-width: 0 !important;
                    margin: 0 !important;
                    background: var(--dsi-bg) !important;
                  }
                  [data-dsi-original-sidebar] {
                    display: none !important;
                    width: 0 !important;
                    min-width: 0 !important;
                    max-width: 0 !important;
                  }
                  [data-dsi-original-header] {
                    display: none !important;
                    width: 0 !important;
                    height: 0 !important;
                    min-height: 0 !important;
                  }
                  [data-dsi-original-composer] {
                    position: absolute !important;
                    left: 0 !important;
                    bottom: 0 !important;
                    width: 1px !important;
                    height: 1px !important;
                    min-height: 1px !important;
                    opacity: 0 !important;
                    overflow: hidden !important;
                    pointer-events: none !important;
                  }
                  [data-dsi-original-composer] input[type="file"] {
                    position: fixed !important;
                    left: 0 !important;
                    top: 0 !important;
                    width: 1px !important;
                    height: 1px !important;
                    opacity: 0 !important;
                  }
                  [data-dsi-disclaimer] { display: none !important; }
                  * { scrollbar-color: #464646 #111 !important; }

                  #dsi-css-shell-v14 {
                    position: fixed !important;
                    z-index: 2147483000 !important;
                    inset: 0 !important;
                    width: 100vw !important;
                    height: 100vh !important;
                    pointer-events: none !important;
                    color: var(--dsi-text) !important;
                    font-family: Arial, sans-serif !important;
                  }
                  #dsi-css-shell-v14 * { box-sizing: border-box !important; }
                  #dsi-css-shell-v14 .dsi-rail {
                    position: absolute !important;
                    left: 0 !important;
                    top: 0 !important;
                    bottom: 0 !important;
                    width: var(--dsi-rail) !important;
                    overflow: hidden !important;
                    padding: 10px 12px !important;
                    background: #101010 !important;
                    border-right: 1px solid rgba(218,170,72,.22) !important;
                    pointer-events: auto !important;
                    transition: width .2s ease !important;
                  }
                  #dsi-css-shell-v14.collapsed .dsi-rail {
                    width: var(--dsi-rail-collapsed) !important;
                  }
                  #dsi-css-shell-v14 .dsi-brand {
                    height: 58px !important;
                    display: flex !important;
                    align-items: center !important;
                    gap: 10px !important;
                    padding: 0 8px !important;
                    color: var(--dsi-gold) !important;
                  }
                  #dsi-css-shell-v14 .dsi-brand strong {
                    color: #fff !important;
                    font: 600 21px/1 Arial, sans-serif !important;
                    letter-spacing: .08em !important;
                  }
                  #dsi-css-shell-v14 .dsi-brand small {
                    display: block !important;
                    margin-top: 4px !important;
                    color: var(--dsi-gold) !important;
                    font: 10px/1.2 Arial, sans-serif !important;
                    white-space: nowrap !important;
                  }
                  #dsi-css-shell-v14 .dsi-collapse {
                    width: 32px !important;
                    height: 32px !important;
                    border: 1px solid #444 !important;
                    border-radius: 9px !important;
                    color: #ddd !important;
                    background: #1e1e1e !important;
                    cursor: pointer !important;
                  }
                  #dsi-css-shell-v14 .dsi-nav {
                    display: flex !important;
                    flex-direction: column !important;
                    gap: 4px !important;
                    margin-top: 8px !important;
                  }
                  #dsi-css-shell-v14 .dsi-spacer { flex: 1 !important; }
                  #dsi-css-shell-v14 .dsi-item,
                  #dsi-css-shell-v14 .dsi-bottom button {
                    display: flex !important;
                    align-items: center !important;
                    width: 100% !important;
                    min-height: 45px !important;
                    border: 0 !important;
                    border-radius: 11px !important;
                    padding: 0 9px !important;
                    color: #eee !important;
                    background: transparent !important;
                    text-align: left !important;
                    cursor: pointer !important;
                    font: 14px/1 Arial, sans-serif !important;
                  }
                  #dsi-css-shell-v14 .dsi-item:hover,
                  #dsi-css-shell-v14 .dsi-bottom button:hover,
                  #dsi-css-shell-v14 .dsi-item.active {
                    background: #3c3c3c !important;
                  }
                  #dsi-css-shell-v14 .dsi-icon {
                    width: 34px !important;
                    flex: 0 0 34px !important;
                    color: #eee !important;
                    font-size: 20px !important;
                    text-align: center !important;
                  }
                  #dsi-css-shell-v14 .dsi-label { white-space: nowrap !important; }
                  #dsi-css-shell-v14.collapsed .dsi-brand small,
                  #dsi-css-shell-v14.collapsed .dsi-brand strong,
                  #dsi-css-shell-v14.collapsed .dsi-label {
                    display: none !important;
                  }
                  #dsi-css-shell-v14.collapsed .dsi-brand {
                    justify-content: center !important;
                    padding: 0 !important;
                  }
                  #dsi-css-shell-v14.collapsed .dsi-item,
                  #dsi-css-shell-v14.collapsed .dsi-bottom button {
                    justify-content: center !important;
                    padding: 0 !important;
                  }
                  #dsi-css-shell-v14 .dsi-bottom {
                    display: flex !important;
                    flex-direction: column !important;
                    gap: 4px !important;
                  }

                  #dsi-css-shell-v14 .dsi-top {
                    position: absolute !important;
                    left: var(--dsi-rail) !important;
                    right: 0 !important;
                    top: 0 !important;
                    height: var(--dsi-top) !important;
                    display: flex !important;
                    align-items: center !important;
                    gap: 18px !important;
                    padding: 0 18px !important;
                    background: #090909 !important;
                    border-bottom: 1px solid rgba(255,255,255,.09) !important;
                    pointer-events: auto !important;
                    transition: left .2s ease !important;
                  }
                  #dsi-css-shell-v14.collapsed .dsi-top {
                    left: var(--dsi-rail-collapsed) !important;
                  }
                  #dsi-css-shell-v14 .dsi-title {
                    min-width: 180px !important;
                    color: #fff !important;
                    font: 600 15px/1.2 Arial, sans-serif !important;
                  }
                  #dsi-css-shell-v14 .dsi-title small {
                    display: block !important;
                    margin-top: 3px !important;
                    color: var(--dsi-gold) !important;
                    font: 9px/1.2 Arial, sans-serif !important;
                  }
                  #dsi-css-shell-v14 .dsi-mode {
                    display: flex !important;
                    width: 194px !important;
                    height: 36px !important;
                    overflow: hidden !important;
                    border: 1px solid #3a3a3a !important;
                    border-radius: 18px !important;
                    background: #141414 !important;
                  }
                  #dsi-css-shell-v14 .dsi-mode button {
                    flex: 1 !important;
                    border: 0 !important;
                    color: #aaa !important;
                    background: transparent !important;
                    cursor: pointer !important;
                    font: 13px/36px Arial, sans-serif !important;
                  }
                  #dsi-css-shell-v14 .dsi-mode button.active {
                    color: #fff !important;
                    background: #262626 !important;
                  }
                  #dsi-css-shell-v14 .dsi-new {
                    margin-left: auto !important;
                    width: 38px !important;
                    height: 38px !important;
                    border: 1px solid #444 !important;
                    border-radius: 11px !important;
                    color: #fff !important;
                    background: #1f1f1f !important;
                    cursor: pointer !important;
                    font-size: 22px !important;
                  }

                  #dsi-css-shell-v14 .dsi-composer {
                    position: absolute !important;
                    left: calc(var(--dsi-rail) + 50%) !important;
                    bottom: 18px !important;
                    transform: translateX(-50%) !important;
                    width: min(780px, calc(100vw - var(--dsi-rail) - 54px)) !important;
                    min-height: 66px !important;
                    display: flex !important;
                    align-items: center !important;
                    gap: 7px !important;
                    padding: 7px !important;
                    border: 1px solid #383838 !important;
                    border-radius: 25px !important;
                    background: var(--dsi-panel) !important;
                    box-shadow: 0 8px 28px rgba(0,0,0,.35) !important;
                    pointer-events: auto !important;
                    transition: left .2s ease, width .2s ease !important;
                  }
                  #dsi-css-shell-v14.collapsed .dsi-composer {
                    left: calc(var(--dsi-rail-collapsed) + 50%) !important;
                    width: min(820px, calc(100vw - var(--dsi-rail-collapsed) - 54px)) !important;
                  }
                  #dsi-css-shell-v14 .dsi-composer textarea {
                    flex: 1 !important;
                    min-width: 0 !important;
                    height: 43px !important;
                    max-height: 86px !important;
                    padding: 10px 10px !important;
                    resize: none !important;
                    outline: none !important;
                    border: 0 !important;
                    color: #eee !important;
                    background: transparent !important;
                    font: 16px/23px Arial, sans-serif !important;
                  }
                  #dsi-css-shell-v14 .dsi-composer textarea::placeholder {
                    color: #9b9b9b !important;
                  }
                  #dsi-css-shell-v14 .dsi-round {
                    width: 48px !important;
                    height: 48px !important;
                    flex: 0 0 48px !important;
                    border: 0 !important;
                    border-radius: 50% !important;
                    color: #fff !important;
                    background: #353535 !important;
                    cursor: pointer !important;
                    font-size: 25px !important;
                  }
                  #dsi-css-shell-v14 .dsi-send {
                    color: #161616 !important;
                    background: var(--dsi-gold) !important;
                    font-size: 24px !important;
                  }
                  #dsi-css-shell-v14 .dsi-attach-menu {
                    position: absolute !important;
                    left: 20px !important;
                    bottom: 86px !important;
                    display: none !important;
                    flex-direction: column !important;
                    width: 142px !important;
                    gap: 5px !important;
                    padding: 7px !important;
                    border: 1px solid #474747 !important;
                    border-radius: 12px !important;
                    background: #242424 !important;
                    pointer-events: auto !important;
                  }
                  #dsi-css-shell-v14.menu-open .dsi-attach-menu {
                    display: flex !important;
                  }
                  #dsi-css-shell-v14 .dsi-attach-menu button {
                    height: 38px !important;
                    border: 0 !important;
                    border-radius: 8px !important;
                    color: #eee !important;
                    background: #333 !important;
                    cursor: pointer !important;
                    text-align: left !important;
                    padding-left: 12px !important;
                    font: 14px/38px Arial, sans-serif !important;
                  }
                  #dsi-css-shell-v14 .dsi-attach-menu button:hover {
                    background: #454545 !important;
                  }
                  /* DSI skin: replace only ChatGPT assistant avatars with the supplied logo. */
                  [data-message-author-role="assistant"] img,
                  img[alt*="ChatGPT"], img[alt*="Assistant"],
                  img[aria-label*="ChatGPT"], img[aria-label*="Assistant"] {
                    content: url("file:///android_asset/dsi-logo.png") !important;
                    object-fit: contain !important;
                    background: #000 !important;
                  }
                  @media (max-width: 900px) {
                    :root {
                      --dsi-rail: 184px;
                      --dsi-rail-collapsed: 58px;
                    }
                    #dsi-css-shell-v14 .dsi-title { min-width: 120px !important; }
                    #dsi-css-shell-v14 .dsi-mode { width: 150px !important; }
                  }
                `;

                document.documentElement.setAttribute('data-dsi-desktop-v14', '1');
              }

              function createShell() {
                if (document.getElementById(SHELL_ID) || !document.body) return;
                var shell = document.createElement('div');
                shell.id = SHELL_ID;
                shell.innerHTML = `
                  <aside class="dsi-rail">
                    <div class="dsi-brand">
                      <div style="flex:1">
                        <strong>DSI</strong>
                        <small>Dimensional Singularity Intelligence</small>
                      </div>
                      <button class="dsi-collapse" type="button">☰</button>
                    </div>
                    <nav class="dsi-nav">
                      <button class="dsi-item active" data-action="new">
                        <span class="dsi-icon">✎</span><span class="dsi-label">新聊天</span>
                      </button>
                      <button class="dsi-item" data-action="history">
                        <span class="dsi-icon">◷</span><span class="dsi-label">聊天记录</span>
                      </button>
                      <button class="dsi-item" data-action="image">
                        <span class="dsi-icon">▧</span><span class="dsi-label">图像</span>
                      </button>
                      <button class="dsi-item" data-action="project">
                        <span class="dsi-icon">⌁</span><span class="dsi-label">项目</span>
                      </button>
                      <button class="dsi-item" data-action="research">
                        <span class="dsi-icon">⌘</span><span class="dsi-label">深度研究</span>
                      </button>
                      <button class="dsi-item" data-action="pricing">
                        <span class="dsi-icon">◇</span><span class="dsi-label">套餐与定价</span>
                      </button>
                    </nav>
                    <div class="dsi-spacer"></div>
                    <div class="dsi-bottom">
                      <button data-action="help"><span class="dsi-icon">◎</span><span class="dsi-label">帮助</span></button>
                      <button data-action="settings"><span class="dsi-icon">⚙</span><span class="dsi-label">设置</span></button>
                    </div>
                  </aside>
                  <header class="dsi-top">
                    <div class="dsi-title">DSI<small>Dimensional Singularity Intelligence</small></div>
                    <div class="dsi-mode">
                      <button class="active" type="button">聊天</button>
                      <button type="button">工作</button>
                    </div>
                    <button class="dsi-new" type="button">＋</button>
                  </header>
                  <div class="dsi-attach-menu">
                    <button type="button" data-upload="image">照片</button>
                    <button type="button" data-upload="file">文件</button>
                  </div>
                  <form class="dsi-composer">
                    <button class="dsi-round dsi-plus" type="button">＋</button>
                    <textarea rows="1" placeholder="询问 ChatGPT"></textarea>
                    <button class="dsi-round dsi-mic" type="button">◌</button>
                    <button class="dsi-round dsi-send" type="submit">↑</button>
                  </form>
                `;
                document.body.appendChild(shell);

                shell.querySelector('.dsi-collapse').addEventListener('click', function () {
                  shell.classList.toggle('collapsed');
                  markPageChrome();
                });
                shell.querySelector('.dsi-plus').addEventListener('click', function () {
                  shell.classList.toggle('menu-open');
                });
                shell.querySelectorAll('[data-upload]').forEach(function (button) {
                  button.addEventListener('click', function () {
                    shell.classList.remove('menu-open');
                    openUpload(button.getAttribute('data-upload') === 'image'
                        ? 'image/*' : '*/*');
                  });
                });
                shell.querySelector('.dsi-new').addEventListener('click', function () {
                  if (!clickPage(/new chat|新聊天|new conversation/i)) {
                    location.href = 'https://chatgpt.com/';
                  }
                });
                shell.querySelector('.dsi-mode button:nth-child(2)').addEventListener(
                    'click', function () {
                      clickPage(/workspace|工作|project|项目/i);
                    });
                shell.querySelector('.dsi-mode button:nth-child(1)').addEventListener(
                    'click', function () {
                      clickPage(/chat|聊天/i);
                    });

                shell.querySelectorAll('[data-action]').forEach(function (button) {
                  button.addEventListener('click', function () {
                    var action = button.getAttribute('data-action');
                    if (action === 'new') {
                      if (!clickPage(/new chat|新聊天|new conversation/i)) {
                        location.href = 'https://chatgpt.com/';
                      }
                    } else if (action === 'history') {
                      clickPage(/history|历史|聊天记录|conversation/i);
                    } else if (action === 'image') {
                      clickPage(/image|图像|图片/i);
                    } else if (action === 'project') {
                      clickPage(/project|项目|workspace/i);
                    } else if (action === 'research') {
                      clickPage(/deep research|深度研究/i);
                    } else if (action === 'pricing') {
                      clickPage(/pricing|套餐|定价/i);
                    } else if (action === 'help') {
                      clickPage(/help|帮助/i);
                    } else if (action === 'settings') {
                      clickPage(/settings|设置/i);
                    }
                  });
                });

                var composer = shell.querySelector('.dsi-composer');
                var input = composer.querySelector('textarea');
                composer.addEventListener('submit', function (event) {
                  event.preventDefault();
                  var value = input.value.trim();
                  if (value) {
                    sendText(value);
                    input.value = '';
                  }
                });
                input.addEventListener('keydown', function (event) {
                  if (event.key === 'Enter' && !event.shiftKey) {
                    event.preventDefault();
                    composer.requestSubmit();
                  }
                });
              }

              function applyDsiAvatars() {
                Array.from(document.querySelectorAll(
                  '[data-message-author-role="assistant"] img,' +
                  'img[alt*="ChatGPT"],img[alt*="Assistant"],' +
                  'img[aria-label*="ChatGPT"],img[aria-label*="Assistant"]'
                )).forEach(function (img) {
                  img.src = 'file:///android_asset/dsi-logo.png';
                  img.style.objectFit = 'contain';
                });
              }

              function apply() {
                installStyle();
                createShell();
                markPageChrome();
                applyDsiAvatars();
              }

              apply();
              [350, 900, 1800, 3200].forEach(function (delay) {
                setTimeout(apply, delay);
              });
              window.addEventListener('resize', apply);
              if (document.body && !window.__dsiDesktopObserverV14) {
                window.__dsiDesktopObserverV14 = true;
                var pending = false;
                new MutationObserver(function () {
                  if (pending) return;
                  pending = true;
                  requestAnimationFrame(function () {
                    pending = false;
                    apply();
                  });
                }).observe(document.body, {childList: true, subtree: true});
              }
            })();
            """;

    private static final String CLEAR_SCRIPT = """
            (function () {
              var shell = document.getElementById('dsi-css-shell-v14');
              if (shell) shell.remove();
              var style = document.getElementById('dsi-css-style-v14');
              if (style) style.remove();
              document.documentElement.removeAttribute('data-dsi-desktop-v14');
              document.body.style.padding = '';
            })();
            """;

    private FrameLayout root;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new FrameLayout(this);
        root.setBackgroundColor(BACKGROUND);
        setContentView(root);
        try {
            configureWindow();
            launchWebView();
        } catch (Throwable error) {
            showError("WebView 启动异常", error);
        }
    }

    private void configureWindow() {
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.BLACK);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        hideSystemBars();
    }

    private void hideSystemBars() {
        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void launchWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(BACKGROUND);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setUserAgentString(DESKTOP_USER_AGENT);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(webView, true);
        }

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;

                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Throwable ignored) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException error) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    showError("系统没有可用的文件选择器", error);
                }
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (isAuthUrl(url)) {
                    view.evaluateJavascript(CLEAR_SCRIPT, null);
                    return;
                }
                applyDesktopLayout(view);
                view.postDelayed(() -> applyDesktopLayout(view), 700L);
                view.postDelayed(() -> applyDesktopLayout(view), 1800L);
                view.postDelayed(() -> applyDesktopLayout(view), 3500L);
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                try {
                    root.removeView(view);
                    view.destroy();
                } catch (Throwable ignored) {
                }
                showErrorText("WebView 渲染进程退出\n请记录这句话和手机型号");
                return true;
            }
        });

        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        webView.loadUrl(START_URL);
    }

    private boolean isAuthUrl(String url) {
        if (url == null) return false;
        String value = url.toLowerCase(java.util.Locale.ROOT);
        return value.contains("auth.openai.com")
                || value.contains("/auth")
                || value.contains("/login")
                || value.contains("/signup");
    }

    private void applyDesktopLayout(WebView view) {
        try {
            view.evaluateJavascript(DESKTOP_SCRIPT, null);
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;

        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) {
                    results[i] = data.getClipData().getItemAt(i).getUri();
                }
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }
        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        CookieManager.getInstance().flush();
        super.onPause();
    }

    private void showError(String title, Throwable error) {
        String detail = error.getClass().getSimpleName();
        if (error.getMessage() != null && !error.getMessage().isEmpty()) {
            detail += "\n" + error.getMessage();
        }
        showErrorText(title + "\n\n" + detail);
    }

    private void showErrorText(String text) {
        if (root == null) return;
        root.removeAllViews();
        TextView message = new TextView(this);
        message.setText(text);
        message.setTextColor(GOLD);
        message.setTextSize(15f);
        message.setGravity(Gravity.CENTER);
        message.setPadding(32, 32, 32, 32);
        message.setBackgroundColor(BACKGROUND);
        root.addView(message, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) {
            try {
                webView.stopLoading();
                webView.destroy();
            } catch (Throwable ignored) {
            }
            webView = null;
        }
        super.onDestroy();
    }
}

