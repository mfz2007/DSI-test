package com.dsi.real;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.CookieManager;
import android.util.Base64;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Desktop WebView host. assets/skin.js styles ChatGPT's native DOM in place,
 * so authentication, messages, model menus and file controls remain native. */
public final class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 4101;
    private WebView webView;
    private ValueCallback<Uri[]> pendingFiles;
    private CookieManager cookieManager;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        // ChatGPT's login flow uses cookies across redirects and embedded auth
        // surfaces.  Keep the WebView session alive just like a desktop browser.
        cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setTextZoom(100);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        // Keep the normal persistent WebView cache/storage path.  In
        // particular, do not use LOAD_NO_CACHE: the ChatGPT auth flow stores
        // its session in cookies and Web Storage across process restarts.
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.setInitialScale(100);
        settings.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/155.0.0.0 Safari/537.36");

        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                // The ChatGPT app is a SPA: its shell and auth controls can be
                // replaced several times after onPageFinished.  Inject once,
                // then signal the skin at each useful DOM-settle point so it can
                // reapply styles to the newly-rendered native nodes.
                injectSkin(view);
                view.postDelayed(() -> signalSkinReady(view), 350);
                view.postDelayed(() -> signalSkinReady(view), 900);
                view.postDelayed(() -> signalSkinReady(view), 1800);
                view.postDelayed(() -> signalSkinReady(view), 3500);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFiles != null) pendingFiles.onReceiveValue(null);
                pendingFiles = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception ignored) { pendingFiles = null; callback.onReceiveValue(null); }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("https://chatgpt.com/");
    }

    private void injectSkin(WebView view) {
        try (InputStream stream = getAssets().open("skin.js")) {
            byte[] bytes = new byte[stream.available()];
            int read = stream.read(bytes);
            String skin = new String(bytes, 0, read, StandardCharsets.UTF_8);
            try (InputStream image = getAssets().open("dsi-logo.png")) {
                byte[] imageBytes = new byte[image.available()];
                int imageRead = image.read(imageBytes);
                String encoded = Base64.encodeToString(imageBytes, 0, imageRead, Base64.NO_WRAP);
                view.evaluateJavascript("window.__DSI_LOGO_PARTS=[];", null);
                final int chunkSize = 180000;
                for (int offset = 0; offset < encoded.length(); offset += chunkSize) {
                    int end = Math.min(offset + chunkSize, encoded.length());
                    view.evaluateJavascript("window.__DSI_LOGO_PARTS.push('" + encoded.substring(offset, end) + "');", null);
                }
                view.evaluateJavascript("window.__DSI_LOGO='data:image/png;base64,'+window.__DSI_LOGO_PARTS.join('');\n" + skin, null);
            }
        } catch (Exception ignored) { }
    }

    private void signalSkinReady(WebView view) {
        if (view == null) return;
        view.evaluateJavascript(
                "window.dispatchEvent(new Event('dsi-webview-ready'));" +
                "if(typeof window.__DSI_APPLY==='function'){window.__DSI_APPLY();}",
                null);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || pendingFiles == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                result = new Uri[count];
                for (int i = 0; i < count; i++) result[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) result = new Uri[]{data.getData()};
        }
        pendingFiles.onReceiveValue(result);
        pendingFiles = null;
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    /** Persist the ChatGPT session whenever Android backgrounds this Activity. */
    @Override protected void onPause() {
        flushCookies();
        super.onPause();
    }

    @Override protected void onStop() {
        flushCookies();
        super.onStop();
    }

    @Override protected void onDestroy() {
        flushCookies();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private void flushCookies() {
        if (cookieManager != null) cookieManager.flush();
    }
}
