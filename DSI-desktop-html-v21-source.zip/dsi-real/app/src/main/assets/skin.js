(() => {
  // Keep ChatGPT as the only application. This is deliberately a small skin:
  // it does not add a second layout, move the composer, resize the sidebar, or
  // replace any native control.
  if (window.__dsiMinimalDomSkin) return;
  window.__dsiMinimalDomSkin = true;

  const body = document.body;
  if (!body) return;
  const root = document.documentElement;
  root.classList.add('dsi-minimal-skin');
  body.classList.add('dsi-minimal-skin');

  const style = document.createElement('style');
  style.id = 'dsi-minimal-dom-style';
  style.textContent = `
:root.dsi-minimal-skin {
  color-scheme: light;
  --dsi-bg: #ffffff;
  --dsi-surface: #f7f7f8;
  --dsi-surface-raised: #ffffff;
  --dsi-text: #202123;
  --dsi-muted: #6b6b6b;
  --dsi-border: #e5e5e5;
  --dsi-accent: #222222;
}

html.dsi-minimal-skin,
body.dsi-minimal-skin {
  background: var(--dsi-bg) !important;
  color: var(--dsi-text) !important;
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont,
    "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif !important;
  -webkit-font-smoothing: antialiased !important;
}

/* Appearance only: no dimensions, positioning, overflow, or display values
   are changed, so ChatGPT's responsive layout remains in charge. */
body.dsi-minimal-skin,
body.dsi-minimal-skin main,
body.dsi-minimal-skin [role="main"],
body.dsi-minimal-skin [data-testid="app"],
body.dsi-minimal-skin #__next,
body.dsi-minimal-skin #root {
  background: var(--dsi-bg) !important;
  color: var(--dsi-text) !important;
}

body.dsi-minimal-skin aside,
body.dsi-minimal-skin nav,
body.dsi-minimal-skin header,
body.dsi-minimal-skin [role="navigation"],
body.dsi-minimal-skin [role="banner"] {
  background: var(--dsi-bg) !important;
  color: var(--dsi-text) !important;
  border-color: var(--dsi-border) !important;
}

body.dsi-minimal-skin * {
  font-family: inherit !important;
  border-color: var(--dsi-border);
}

body.dsi-minimal-skin button,
body.dsi-minimal-skin [role="button"] {
  color: var(--dsi-text) !important;
}

body.dsi-minimal-skin button:hover,
body.dsi-minimal-skin [role="button"]:hover,
body.dsi-minimal-skin [aria-selected="true"],
body.dsi-minimal-skin [data-state="active"] {
  background: var(--dsi-surface) !important;
  color: var(--dsi-accent) !important;
}

body.dsi-minimal-skin input,
body.dsi-minimal-skin textarea,
body.dsi-minimal-skin [contenteditable="true"] {
  color: var(--dsi-text) !important;
  caret-color: var(--dsi-text) !important;
  background: transparent !important;
}

body.dsi-minimal-skin input::placeholder,
body.dsi-minimal-skin textarea::placeholder,
body.dsi-minimal-skin [contenteditable="true"]:empty::before {
  color: var(--dsi-muted) !important;
}

body.dsi-minimal-skin a {
  color: var(--dsi-text) !important;
}

body.dsi-minimal-skin [role="dialog"],
body.dsi-minimal-skin [role="menu"],
body.dsi-minimal-skin [role="listbox"],
body.dsi-minimal-skin [data-radix-popper-content-wrapper] > *,
body.dsi-minimal-skin [data-floating-ui-portal] > * {
  color: var(--dsi-text) !important;
  background: var(--dsi-surface-raised) !important;
  border-color: var(--dsi-border) !important;
}

body.dsi-minimal-skin pre,
body.dsi-minimal-skin code {
  color: var(--dsi-text) !important;
  background: var(--dsi-surface) !important;
  border-color: var(--dsi-border) !important;
}

body.dsi-minimal-skin svg {
  color: currentColor !important;
}

/* Keep conversation layout and content native while using one page-wide font
   and text color. */
body.dsi-minimal-skin [data-message-author-role],
body.dsi-minimal-skin [data-testid^="conversation-turn"] {
  color: var(--dsi-text) !important;
  font-family: inherit !important;
}

body.dsi-minimal-skin [data-message-author-role] a,
body.dsi-minimal-skin [data-message-author-role] code,
body.dsi-minimal-skin [data-message-author-role] pre {
  color: inherit !important;
}

`;
  document.head.appendChild(style);

  const logo = window.__DSI_LOGO || '';
  const isConversation = (el) => !!(el && el.closest(
    '[data-message-author-role],[data-testid^="conversation-turn"],article[data-testid*="conversation" i]'
  ));
  const isEditable = (el) => !!(el && el.closest('textarea,input,[contenteditable="true"]'));
  const replaceBrand = (value) => value
    .replace(/ChatGPT/gi, 'DSI')
    .replace(/\bGPT(?=[-\s]|$)/gi, 'DSI');

  // Replace only visible UI labels. Conversation text is deliberately left
  // untouched so user and assistant messages remain faithful to ChatGPT.
  const replaceText = () => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      const parent = node.parentElement;
      if (!parent || isConversation(parent) || isEditable(parent)) continue;
      if (/^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA|INPUT)$/i.test(parent.tagName)) continue;
      const next = replaceBrand(node.nodeValue);
      if (next !== node.nodeValue) node.nodeValue = next;
    }

    document.body.querySelectorAll('[aria-label],[title],[alt]').forEach((el) => {
      if (isConversation(el)) return;
      ['aria-label', 'title', 'alt'].forEach((attr) => {
        const value = el.getAttribute(attr);
        if (value && /ChatGPT|\bGPT(?=[-\s]|$)/i.test(value)) {
          el.setAttribute(attr, replaceBrand(value));
        }
      });
    });
    if (document.title) document.title = replaceBrand(document.title);
  };

  // The input remains native; only its existing visible labels are renamed.
  const replaceNativeLabels = () => {
    document.body.querySelectorAll('textarea,input,[contenteditable="true"]').forEach((el) => {
      ['placeholder', 'aria-label', 'data-placeholder'].forEach((attr) => {
        const value = el.getAttribute(attr);
        if (value && /ChatGPT|\bGPT(?=[-\s]|$)/i.test(value)) {
          el.setAttribute(attr, replaceBrand(value));
        }
      });
    });
  };

  // Change a recognisable ChatGPT/OpenAI brand image to the supplied DSI logo
  // without touching ordinary message images or icon SVGs.
  const replaceBrandImages = () => {
    if (!logo) return;
    document.body.querySelectorAll('img').forEach((img) => {
      if (isConversation(img)) return;
      const marker = [img.alt, img.title, img.getAttribute('aria-label'), img.src]
        .filter(Boolean).join(' ');
      if (/chatgpt|openai/i.test(marker)) {
        if (img.src !== logo) img.src = logo;
        img.alt = 'DSI';
      }
    });
  };

  let queued = false;
  const apply = () => {
    if (queued) return;
    queued = true;
    window.setTimeout(() => {
      queued = false;
      replaceText();
      replaceNativeLabels();
      replaceBrandImages();
    }, 80);
  };
  window.__DSI_APPLY = apply;
  apply();
  // Observe structural/text changes only; scanning every attribute mutation made
  // the WebView busy while ChatGPT streams or animates its UI.
  new MutationObserver(apply).observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true
  });
  window.setInterval(() => {
    if (!document.hidden) {
      replaceNativeLabels();
      replaceBrandImages();
    }
  }, 1200);
  window.addEventListener('pageshow', apply);
  window.addEventListener('dsi-webview-ready', apply);
})();
