(() => {
  // Direct ChatGPT DOM skin.  No second app, iframe, composer, or message list
  // is created: ChatGPT remains the only page and keeps native handlers.
  if (window.__dsiDirectDomSkin) return;
  window.__dsiDirectDomSkin = true;
  const logo = window.__DSI_LOGO || '';
  const html = document.documentElement;
  const body = document.body;
  if (!body) return;
  body.classList.add('dsi-direct-skin');
  html.classList.add('dsi-direct-skin');

  const style = document.createElement('style');
  style.id = 'dsi-direct-dom-style';
  style.textContent = `
:root { color-scheme:dark; --dsi-black:#000; --dsi-surface:#050505; --dsi-panel:#0b0906; --dsi-panel-2:#11100d; --dsi-gold:#e6b85f; --dsi-gold-strong:#f2cb78; --dsi-gold-soft:#b99759; --dsi-line:rgba(230,184,95,.28); --dsi-hover:rgba(230,184,95,.12); }
html.dsi-direct-skin, body.dsi-direct-skin { min-width:1024px!important; min-height:100%!important; background:var(--dsi-black)!important; color:var(--dsi-gold)!important; font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif!important; -webkit-font-smoothing:antialiased!important; }
body.dsi-direct-skin { overflow-x:auto!important; }
body.dsi-direct-skin *,body.dsi-direct-skin *::before,body.dsi-direct-skin *::after { scrollbar-color:rgba(230,184,95,.35) transparent; }
body.dsi-direct-skin main,body.dsi-direct-skin [role="main"],body.dsi-direct-skin [data-testid="main-content"],body.dsi-direct-skin #__next,body.dsi-direct-skin #root,body.dsi-direct-skin [data-testid="app"] { background:var(--dsi-black)!important; }
body.dsi-direct-skin aside,body.dsi-direct-skin nav,body.dsi-direct-skin [data-testid="navigation-sidebar"],body.dsi-direct-skin [data-testid="sidebar"] { background:var(--dsi-surface)!important; border-color:var(--dsi-line)!important; color:var(--dsi-gold-soft)!important; }
body.dsi-direct-skin aside,body.dsi-direct-skin [data-testid="navigation-sidebar"] { width:clamp(214px,16.7vw,276px)!important; min-width:214px!important; }
body.dsi-direct-skin header,body.dsi-direct-skin [role="banner"],body.dsi-direct-skin main>div:first-child { border-color:var(--dsi-line)!important; }
body.dsi-direct-skin button,body.dsi-direct-skin [role="button"] { color:var(--dsi-gold-soft)!important; border-color:var(--dsi-line)!important; font-family:inherit!important; }
body.dsi-direct-skin button:hover,body.dsi-direct-skin [role="button"]:hover { color:var(--dsi-gold-strong)!important; background:var(--dsi-hover)!important; }
body.dsi-direct-skin input,body.dsi-direct-skin textarea,body.dsi-direct-skin [contenteditable="true"] { color:var(--dsi-gold-strong)!important; caret-color:var(--dsi-gold-strong)!important; font-family:inherit!important; }
body.dsi-direct-skin input::placeholder,body.dsi-direct-skin textarea::placeholder,body.dsi-direct-skin [contenteditable="true"]:empty::before { color:#796744!important; }
body.dsi-direct-skin [role="dialog"],body.dsi-direct-skin [role="menu"],body.dsi-direct-skin [data-radix-popper-content-wrapper]>*,body.dsi-direct-skin [data-floating-ui-portal]>* { color:var(--dsi-gold-soft)!important; background:var(--dsi-panel-2)!important; border-color:var(--dsi-line)!important; }
body.dsi-direct-skin [role="menuitem"]:hover,body.dsi-direct-skin [role="option"]:hover,body.dsi-direct-skin [data-state="checked"],body.dsi-direct-skin [aria-selected="true"] { color:var(--dsi-gold-strong)!important; background:var(--dsi-hover)!important; }
body.dsi-direct-skin [data-message-author-role] { width:min(850px,calc(100% - 52px))!important; max-width:850px!important; margin-left:auto!important; margin-right:auto!important; color:var(--dsi-gold-soft)!important; font-family:inherit!important; line-height:1.7!important; }
body.dsi-direct-skin [data-message-author-role] p,body.dsi-direct-skin [data-message-author-role] li,body.dsi-direct-skin [data-message-author-role] code,body.dsi-direct-skin [data-message-author-role] pre { color:inherit!important; font-family:inherit!important; }
body.dsi-direct-skin [data-message-author-role="user"] { color:var(--dsi-gold-strong)!important; }
body.dsi-direct-skin [data-message-author-role="user"]>div { background:var(--dsi-panel-2)!important; border:1px solid var(--dsi-line)!important; border-radius:14px!important; }
body.dsi-direct-skin pre,body.dsi-direct-skin code { background:#080706!important; border-color:var(--dsi-line)!important; }
body.dsi-direct-skin .dsi-native-main { min-width:0!important; background:var(--dsi-black)!important; }
body.dsi-direct-skin .dsi-native-composer { width:min(64vw,760px)!important; min-width:520px!important; margin-left:auto!important; margin-right:auto!important; border:1px solid var(--dsi-line)!important; border-radius:14px!important; background:#020202!important; box-shadow:0 8px 40px rgba(0,0,0,.45)!important; color:var(--dsi-gold-soft)!important; }
body.dsi-direct-skin .dsi-native-composer textarea,body.dsi-direct-skin .dsi-native-composer [contenteditable="true"] { min-height:30px!important; padding:8px 10px!important; background:transparent!important; border:0!important; outline:0!important; font-size:14px!important; line-height:1.45!important; }
body.dsi-direct-skin .dsi-native-composer button[aria-label*="Send" i],body.dsi-direct-skin .dsi-native-composer button[aria-label*="发送"],body.dsi-direct-skin .dsi-native-composer button[data-testid*="send" i] { color:#120d04!important; background:var(--dsi-gold-strong)!important; border-radius:9px!important; }
body.dsi-direct-skin .dsi-native-composer button[aria-label*="Attach" i],body.dsi-direct-skin .dsi-native-composer button[aria-label*="附件"] { color:var(--dsi-gold-soft)!important; }
body.dsi-direct-skin.dsi-empty-chat .dsi-native-main { display:flex!important; flex-direction:column!important; justify-content:center!important; }
body.dsi-direct-skin.dsi-empty-chat .dsi-native-composer { position:relative!important; inset:auto!important; margin-top:18px!important; margin-bottom:8vh!important; }
body.dsi-direct-skin.dsi-has-chat .dsi-native-composer { position:sticky!important; bottom:0!important; z-index:5!important; }
body.dsi-direct-skin .dsi-assistant-avatar img,body.dsi-direct-skin [data-message-author-role="assistant"] img { width:28px!important; height:28px!important; object-fit:contain!important; filter:none!important; }
body.dsi-direct-skin .dsi-assistant-avatar { border-color:var(--dsi-line)!important; background:#000!important; }
body.dsi-direct-skin .dsi-project-surface,body.dsi-direct-skin .dsi-image-surface,body.dsi-direct-skin .dsi-file-surface { color:var(--dsi-gold-soft)!important; background:var(--dsi-black)!important; border-color:var(--dsi-line)!important; }
/* ChatGPT changes these workspaces between releases.  Cover their stable
   test-id/aria-label hooks as well as the marker classes above, without
   replacing the native controls or their click handlers. */
body.dsi-direct-skin [data-testid*="project" i],body.dsi-direct-skin [data-testid*="image" i],body.dsi-direct-skin [data-testid*="file" i],body.dsi-direct-skin [data-testid*="workspace" i],body.dsi-direct-skin [data-testid*="library" i],body.dsi-direct-skin [aria-label*="project" i],body.dsi-direct-skin [aria-label*="image" i],body.dsi-direct-skin [aria-label*="file" i],body.dsi-direct-skin [aria-label*="workspace" i] { color:var(--dsi-gold-soft)!important; border-color:var(--dsi-line)!important; }
body.dsi-direct-skin [data-testid*="project" i] [class*="bg-"],body.dsi-direct-skin [data-testid*="image" i] [class*="bg-"],body.dsi-direct-skin [data-testid*="file" i] [class*="bg-"] { background:var(--dsi-panel)!important; }
body.dsi-direct-skin [data-testid*="project" i],body.dsi-direct-skin [data-testid*="file" i],body.dsi-direct-skin [data-testid*="image" i],body.dsi-direct-skin [aria-label*="project" i],body.dsi-direct-skin [aria-label*="项目"],body.dsi-direct-skin [aria-label*="file" i],body.dsi-direct-skin [aria-label*="文件"] { color:var(--dsi-gold-soft)!important; border-color:var(--dsi-line)!important; }
body.dsi-direct-skin [data-testid*="project" i] main,body.dsi-direct-skin [data-testid*="file" i] main,body.dsi-direct-skin [data-testid*="image" i] main { background:var(--dsi-black)!important; }
body.dsi-direct-skin [data-testid*="login" i],body.dsi-direct-skin [id*="login" i],body.dsi-direct-skin [data-testid*="auth" i] { color:var(--dsi-gold-soft)!important; background:var(--dsi-surface)!important; border-color:var(--dsi-line)!important; }
body.dsi-direct-skin [data-testid*="login" i] input,body.dsi-direct-skin [id*="login" i] input,body.dsi-direct-skin [data-testid*="auth" i] input { color:var(--dsi-gold-strong)!important; background:#080706!important; border-color:var(--dsi-line)!important; }
body.dsi-direct-skin svg { color:currentColor!important; }
@media (max-width:760px) { body.dsi-direct-skin { min-width:1024px!important; } }
@media (prefers-reduced-motion:reduce) { body.dsi-direct-skin *,body.dsi-direct-skin *::before,body.dsi-direct-skin *::after { transition-duration:.01ms!important; animation-duration:.01ms!important; } }
`;
  document.head.appendChild(style);
  if (logo) {
    style.textContent += `body.dsi-direct-skin .dsi-assistant-avatar:not(:has(img)){background-image:url("${logo}")!important;background-size:contain!important;background-repeat:no-repeat!important;background-position:center!important;}`;
  }

  const textWalker = () => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      const parent = node.parentElement;
      if (!parent || /^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA|INPUT)$/i.test(parent.tagName)) continue;
      if (parent.closest('[data-message-author-role],[data-testid^="conversation-turn"]')) continue;
      const before = node.nodeValue;
      let after = before.replace(/\bGPT(?=[-\s])/g,'DSI');
      if (/^\s*ChatGPT\s*$/i.test(after)) after = after.replace(/ChatGPT/ig,'DSI');
      else if (/^(\s*(?:Ask|询问)\s+)ChatGPT(\b.*)$/i.test(after)) after = after.replace(/ChatGPT/ig,'DSI');
      if (after !== before) node.nodeValue = after;
    }
  };
  const findInput = () => document.querySelector('textarea#prompt-textarea,textarea[placeholder*="Message" i],textarea[placeholder*="消息" i],[contenteditable="true"][role="textbox"],[contenteditable="true"]');
  const markLayout = () => {
    const input = findInput();
    document.querySelectorAll('.dsi-native-composer').forEach(el => { if (!el.contains(input)) el.classList.remove('dsi-native-composer'); });
    if (input) {
      let composer = input.closest('form');
      if (!composer) {
        let p = input.parentElement;
        for (let i=0;p&&i<7;i++,p=p.parentElement) { const r=p.getBoundingClientRect(); if (r.width>300&&p.querySelector('button')) { composer=p; break; } }
      }
      if (composer) composer.classList.add('dsi-native-composer');
      const main = input.closest('main') || input.closest('[role="main"]') || document.querySelector('main,[role="main"]');
      if (main) main.classList.add('dsi-native-main');
    }
    const messages = document.querySelector('[data-message-author-role],[data-testid^="conversation-turn"]');
    body.classList.toggle('dsi-has-chat',!!messages);
    body.classList.toggle('dsi-empty-chat',!messages);
  };
  const markAvatars = () => {
    document.querySelectorAll('[data-message-author-role="assistant"]').forEach(message => {
      const candidate = message.querySelector('img,button,[class*="avatar" i],svg');
      if (!candidate) return;
      const avatar = candidate.closest('button,[class*="avatar" i]') || candidate.parentElement || candidate;
      avatar.classList.add('dsi-assistant-avatar');
      const img = avatar.matches('img') ? avatar : avatar.querySelector('img');
      if (img && logo) { img.src=logo; img.alt='DSI'; }
    });
  };
  let queued=false;
  const refresh=()=>{ if(queued)return; queued=true; requestAnimationFrame(()=>{ queued=false; markLayout(); markAvatars(); textWalker(); }); };
  window.__DSI_APPLY=refresh;
  refresh();
  new MutationObserver(refresh).observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['class','data-state','aria-selected']});
  window.addEventListener('pageshow',refresh);
  window.addEventListener('resize',refresh);
  window.addEventListener('dsi-webview-ready',refresh);
})();
