# DSI Desktop Skin

Independent Android WebView project for the DSI desktop skin.

The app keeps real ChatGPT WebView content and applies a DSI black-gold desktop shell, compact composer, collapsible sidebar, and DSI assistant avatar.
